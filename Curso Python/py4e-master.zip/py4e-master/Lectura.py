fhand = open('mbox2.txt')
inp = fhand.read()
print(len(inp))
print(inp[:100])
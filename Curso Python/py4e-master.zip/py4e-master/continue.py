variable = 10
while variable > 0:              
   variable = variable -1
   if variable == 5:
      continue
   print ('Actual valor de variable:', variable)
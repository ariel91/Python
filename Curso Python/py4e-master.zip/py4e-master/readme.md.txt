
git remote add origin https://gitlab.com/ariel91/py4e.git

git remote add origin git@gitlab.com:ariel91/py4e.git
	git push -u origin master
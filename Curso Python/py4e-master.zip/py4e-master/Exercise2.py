score = input ("Ingrese nota")
ingreso = float (score)
if ingreso >= 0.9:
    print("A")
    elif ingreso >= 0.8:
        print("B")
    elif ingreso >= 0.7:
        print("C")
    elif ingreso >= 0.6:
        print("D")
    else:
        print("F")

stuff = 'Hello\nWorld!'
print(stuff)
stuff = 'X\nY'
print(stuff)
len(stuff)
fhand= open('mbox2.txt')
print(fhand)

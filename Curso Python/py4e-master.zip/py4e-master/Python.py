https://www.py4e.com/lessons
bajar https://www.anaconda.com/download/
 jupyter notebook
 https://automatetheboringstuff.com/chapter13/
 https://www.coursera.org/specializations/python
 libro: https://books.trinket.io/pfe/index.html
https://automatetheboringstuff.com/

Environment
overview
helpful

PYTHON

Ingresar en el cmd: python
Mensajes: print('Hola mundo')
Salir: Control + Z
Ver carpetas y archivos : dir
Ubicacion: cd

WORDS AND SENTENCES

The reserved words in the language where humans talk to Python include the following:

and       del       global      not       with
as        elif      if          or        yield
assert    else      import      pass
break     except    in          raise
class     finally   is          return
continue  for       lambda      try
def       from      nonlocal    while    

